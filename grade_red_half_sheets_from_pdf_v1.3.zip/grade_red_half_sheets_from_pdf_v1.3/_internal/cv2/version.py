opencv_version = "4.13.0.92"
contrib = False
headless = False
rolling = False
ci_build = True